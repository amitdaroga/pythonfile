from selenium import webdriver
from python3_anticaptcha import ImageToTextTask
from time import sleep
import requests
import datetime
import os
import shutil
import zipfile
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import WebDriverException
from selenium import webdriver
import time
import sqlite3
import logging
import requests
from os.path import basename
import pyodbc as pyodbc
import urllib.request



a, b = 0, 1
for i in range(0,11):
    if i == 0:
        s = a
        print(0)
        print(1)
    else:
        s = a + b
        a = b
        b = s
        print(b)












